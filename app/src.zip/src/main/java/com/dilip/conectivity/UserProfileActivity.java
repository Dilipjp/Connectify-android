package com.dilip.conectivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserProfileActivity extends AppCompatActivity {
    private String currentUserId, profileUserId;
    private DatabaseReference usersRef;
    private FirebaseAuth mAuth;

    private ImageView userProfileImage;
    private TextView userNameTextView;
    private Button followButton;
    private boolean isFollowing = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Get the profileUserId from Intent
        profileUserId = getIntent().getStringExtra("profileUserId");

        mAuth = FirebaseAuth.getInstance();
        currentUserId = mAuth.getCurrentUser().getUid();
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");

        userProfileImage = findViewById(R.id.userProfileImage);
        userNameTextView = findViewById(R.id.userNameTextView);
        followButton = findViewById(R.id.followButton);

        fetchUserProfileData();
        checkFollowStatus();

        followButton.setOnClickListener(v -> {
            if (isFollowing) {
                unfollowUser();
            } else {
                followUser();
            }
        });
    }

    // Fetch the user profile data
    private void fetchUserProfileData() {
        usersRef.child(profileUserId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String userName = dataSnapshot.child("userName").getValue().toString();
                    userNameTextView.setText(userName);

                    // Optionally load profile image (handle image loading if needed)
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors that occur while fetchin
